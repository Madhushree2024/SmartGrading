python Libraries:
streamlit

Install the required libraries using:
pip install streamlit

How to Run the Application

1.download the project files.

2.Navigate to the project directory.

3.Run the following command:
  streamlit run EDITECH.py

4.The application will open in your default web browser.